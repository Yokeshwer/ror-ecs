class Author < ApplicationRecord
end
