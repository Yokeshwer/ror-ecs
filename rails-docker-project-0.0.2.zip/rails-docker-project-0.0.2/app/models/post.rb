class Post < ApplicationRecord
  belongs_to :author
end
