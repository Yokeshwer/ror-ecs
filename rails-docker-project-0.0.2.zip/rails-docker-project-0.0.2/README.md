# Rails Docker Project

This project is the source code to my blog series: https://dev.to/jamby1100/more-than-hello-world-in-docker-run-rails-sidekiq-web-apps-in-docker-1b37.

